package com.xbl.dao;

import java.io.IOException;
import java.util.List;

import org.dom4j.Document;

import com.xbl.pojo.Entity;

public interface YueCaiDao {
	//查询全部
	public List<Entity> selAll(Document document,String type);
	//增加
	public  void addFood(Document document,String id1,String FoodName1,String image1,String introduct1,String price1) throws IOException;
	//修改
	public  void updateFood(Document document,String id1,String FoodName1,String image1,String introduct1,String price1) throws IOException;
	//删除
	public  void delFood(Document document,String ID) throws IOException;
	//查询
	public List<Entity> Querry(Document document,String type,String sort,String value,String path);
	//注册
	public  void register(Document document,String ID,String UserName,String PassWord) throws IOException;
}
