package com.xbl.dao.Impl;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.XMLWriter;

import com.xbl.dao.YueCaiDao;
import com.xbl.pojo.Entity;

public class YueCaiDaoImpl implements YueCaiDao {
	GetDocument get=new GetDocument();

	//显示全部
	@Override
	public List<Entity> selAll(Document document,String type) {
		List<Entity> et=new ArrayList<Entity>();
		ArrayList save=new ArrayList();
		Element root=document.getRootElement();
		List list=root.elements();
		for(int i=0;i<list.size();i++) {
			Element food=(Element) list.get(i);
			String id=food.attributeValue("FoodID");
			List ll=food.elements();
			for(int j=0;j<ll.size();j++) {
				Element element=(Element) ll.get(j);
				if(type.equals(element.getName())) {
					String content=element.getText();
					save.add(content);
				}
			}
		}
		return save;
		
	}
	
	//添加
	@Override
	public void addFood(Document document,String id1,String FoodName1,String image1,String introduct1,String price1) throws IOException {
		Element root=document.getRootElement();
		Element newFood=root.addElement("Food");
		newFood.addAttribute("FoodID",id1);
		Element FoodName=newFood.addElement("FoodName");
		FoodName.setText(FoodName1);
		Element image=newFood.addElement("image");
		image.setText(image1);
		Element introduct=newFood.addElement("introduct");
		introduct.setText(introduct1);
		Element price=newFood.addElement("price");
		price.setText(price1);	
		get.saveXml(document);

	}
	//修改
	@Override
	public void updateFood(Document document,String id1,String FoodName1,String image1,String introduct1,String price1) throws IOException {
		 Element root = document.getRootElement();
		    List et = root.elements();
		    for (int i = 0; i < et.size(); i++) {
		 
		      Element book = (Element) et.get(i);
		      if (id1.equals(book.attributeValue("FoodID"))) {
		 
		        for (Iterator it = book.elementIterator(); it.hasNext();) {
		          Element node = (Element) it.next();
		          String type = node.getName();
		          if ("FoodName".equals(type)) {
		            node.setText(FoodName1);
		          }
		          if ("image".equals(type)) {
			            node.setText(image1);
			          }
		          if ("introduct".equals(type)) {
		            node.setText(introduct1);
		          }
		          if ("price".equals(type)) {
			            node.setText(price1);
			          }
		        }
		      }
		    }
		 
		 get.saveXml(document);
	}
	//删除
	public void delFood(Document document,String ID) throws IOException{
		 Element root = document.getRootElement();
		    for (Iterator it = root.elementIterator(); it.hasNext();) {
		      Element food = (Element) it.next();
		      String FoodID = food.attributeValue("FoodID");
		      if (ID.equals(FoodID)) {
		        Element parent = food.getParent();
		        parent.remove(food);
		      }
		  }
		 //保存
		    get.saveXml(document);
	}
	
	//模糊	 
	public List<Entity> Querry(Document document,String type,String sort,String value,String path) {
		ArrayList al= new ArrayList();
		
		List list= document.selectNodes(path+"[contains("+type+",'" + value + "')]");  
		
		
		Iterator iterator=list.iterator();
		while(iterator.hasNext()) {
			Element element = (Element)iterator.next();  
			List ll=element.elements();
			for(int i=0;i<ll.size();i++) {				//��ȡ���ӽڵ�
				Element es=(Element) ll.get(i);
				if(sort.equals(es.getName())) {
					String content=es.getText();
					al.add(content);
				}
			}
		}
		return al;	
	}
	//精准查询
	public List<Entity> JZQuerry(Document document,String type,String value,String path) {
		ArrayList al= new ArrayList();
		
		List list= document.selectNodes(path+"["+type+"='" + value + "']");  
		
		
		Iterator iterator=list.iterator();
		while(iterator.hasNext()) {
			Element element = (Element)iterator.next();  
			List ll=element.elements();
			for(int i=0;i<ll.size();i++) {
				//获取字节点
				Element es=(Element) ll.get(i);
				al.add(es.getText());
			}
		}
		return al;	
	}
//注册
	@Override
	public void register(Document document, String ID,String UserName1, String PassWord1) throws IOException {
		Element root=document.getRootElement();
		Element newUser=root.addElement("User");
		newUser.addAttribute("userId",ID);
		Element UserName=newUser.addElement("UserName");
		UserName.setText(UserName1);
		Element PassWord=newUser.addElement("UserPassWord");
		PassWord.setText(PassWord1);
		get.saveXml1(document);
		
	}
}
