package com.xbl.dao.Impl;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.net.URL;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.io.SAXReader;
import org.dom4j.io.XMLWriter;

public class GetDocument {
	//读取XML文档
	public  Document getDocument(String path) throws Exception {
		SAXReader sr=new SAXReader();
		File file=new File(this.getClass().getResource(path).getPath());
		
		Document document=sr.read(file);
		return document;
	}
	//保存

	public  void saveXml(Document document) throws IOException {
		
//		 OutputStreamWriter out = new OutputStreamWriter(new FileOutputStream(this.getClass().getResource("/Food.xml").getPath()),"UTF-8");
		 OutputStreamWriter out = new OutputStreamWriter(new FileOutputStream("C:\\Users\\Administrator\\Desktop\\XML实训\\XML\\resources\\Food.xml"),"UTF-8");
		 document.write(out);
		 out.close();
//		XMLWriter writer = new XMLWriter(new FileWriter("C:\\Users\\Administrator\\Desktop\\XML实训\\XML\\resources\\Food.xml"));
//        writer.write(document);
//        writer.close();

	}
	public  void saveXml1(Document document) throws IOException {
		
//		 OutputStreamWriter out = new OutputStreamWriter(new FileOutputStream(this.getClass().getResource("/Food.xml").getPath()),"UTF-8");
		 OutputStreamWriter out = new OutputStreamWriter(new FileOutputStream("C:\\Users\\Administrator\\Desktop\\XML实训\\XML\\resources\\User.xml"),"UTF-8");
		 document.write(out);
		 out.close();
//		XMLWriter writer = new XMLWriter(new FileWriter(this.getClass().getResource("/User.xml").getPath()));
//		XMLWriter writer = new XMLWriter(new FileWriter("C:\\Users\\Administrator\\Desktop\\XML实训\\XML\\resources\\User.xml"));
//       writer.write(document);
//       writer.close();

	}

}
