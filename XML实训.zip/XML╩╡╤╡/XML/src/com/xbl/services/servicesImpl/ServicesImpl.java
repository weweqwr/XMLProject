package com.xbl.services.servicesImpl;

import java.io.IOException;
import java.util.List;

import org.dom4j.Document;
import org.dom4j.Entity;

import com.xbl.dao.Impl.GetDocument;
import com.xbl.dao.Impl.YueCaiDaoImpl;
import com.xbl.services.Services;

public class ServicesImpl implements Services{
	GetDocument get=new GetDocument();
	YueCaiDaoImpl ydi=new YueCaiDaoImpl();
	@Override
	public List<Entity> login(String value) throws Exception {
		Document document=get.getDocument("/User.xml");
		List list=ydi.JZQuerry(document, "UserName",value,"/Users/User");
		return list;
	}

	@Override
	public List<Entity> index(String value) throws Exception {
		// TODO Auto-generated method stub
		Document document=get.getDocument("/Food.xml");
		List list=ydi.selAll(document, value);
		return list;
	}

	@Override
	public List<Entity> Querry(String type,String sort,String value) throws Exception {
		// TODO Auto-generated method stub
		Document document=get.getDocument("/Food.xml");
		List list=ydi.Querry(document, type,sort,value, "/Foods/Food");
		return list;
	}

	@Override
	public void adminAdd(String id1,String FoodName1,String image1,String introduct1,String price1) throws IOException {
		// TODO Auto-generated method stub
		
		try {
			Document document = get.getDocument("/Food.xml");
			ydi.addFood(document, id1, FoodName1, image1, introduct1, price1);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void adminupdate(String id1,String FoodName1,String image1,String introduct1,String price1) throws IOException {
		
		try {
			Document document = get.getDocument("/Food.xml");
			ydi.updateFood(document, id1, FoodName1, image1, introduct1, price1);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	@Override
	public void admindelete(String ID) throws IOException {
		// TODO Auto-generated method stub
		try {
			Document document = get.getDocument("/Food.xml");
			ydi.delFood(document, ID);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	//注册
	@Override
	public void register(String ID,String UserName,String PassWord) throws IOException {
		try {
			Document document = get.getDocument("/User.xml");
			ydi.register(document, ID, UserName, PassWord);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
