package com.xbl.services;

import java.io.IOException;
import java.util.List;

import org.dom4j.Document;
import org.dom4j.Entity;

public interface Services {
	//登陆
	public List<Entity> login(String value) throws Exception;
	//首页
	public List<Entity> index(String value) throws Exception;
	//查询
	public List<Entity> Querry(String type,String sort,String value) throws Exception;
	//管理员添加
	public void adminAdd(String id1,String FoodName1,String image1,String introduct1,String price1) throws IOException;
	//管理员修改
	public void adminupdate(String id1,String FoodName1,String image1,String introduct1,String price1) throws IOException;
	//管理员删除
	public void admindelete(String ID) throws IOException;
	//注册
	public void register(String ID,String UserName,String PassWord) throws IOException;
}
