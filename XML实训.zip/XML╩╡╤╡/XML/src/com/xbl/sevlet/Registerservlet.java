package com.xbl.sevlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.xbl.services.Services;
import com.xbl.services.servicesImpl.ServicesImpl;

/**
 * Servlet implementation class registerservlet
 */
@WebServlet("/Registerservlet")
public class Registerservlet extends HttpServlet {
	private Services ser=new ServicesImpl();
	@Override
	public void service(ServletRequest req, ServletResponse res) throws ServletException, IOException {
		// TODO Auto-generated method stub
		res.setCharacterEncoding("UTF-8");
		req.setCharacterEncoding("UTF-8");
		String UserName=req.getParameter("UserName");
		String PassWord=req.getParameter("PassWord");
		String PassWords=req.getParameter("PassWords");
		PrintWriter out = res.getWriter();
		if(UserName == null || "".equals(UserName.trim())||PassWord == null || "".equals(PassWord.trim())||PassWords == null || "".equals(PassWords.trim())) {
			out.print("用户名、密码不能为空");
		}
		else{
			if(PassWords.equals(PassWord)) {
				out.print("注册成功");
			System.out.print(UserName+PassWord+PassWords);
			ser.register("10", UserName, PassWord);
			}else if(PassWords.equals(PassWord)==false) {
				out.print("密码必须一致");
			}
		}
		
	}
	
}
