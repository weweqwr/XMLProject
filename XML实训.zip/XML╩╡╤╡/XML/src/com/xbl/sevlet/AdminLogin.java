package com.xbl.sevlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.xbl.services.Services;
import com.xbl.services.servicesImpl.ServicesImpl;

/**
 * Servlet implementation class AdminLogin
 */
@WebServlet("/AdminLogin")
public class AdminLogin extends HttpServlet {
	private Services ser=new ServicesImpl();
	
	@Override
	protected void service(HttpServletRequest req,HttpServletResponse res) throws  ServletException,IOException {
		String us=null;
		String pw=null;
		String UserName=null;
		String PassWord=null;
		String inputCode=null;
		String verifyCode =null;
		String UserNameLogin=null;
		String admin=null;
		int f=0;//登陆标识
		try {
			res.setCharacterEncoding("UTF-8");
			req.setCharacterEncoding("UTF-8");
			UserName=req.getParameter("UserName");
			PassWord=req.getParameter("PassWord");
			inputCode=req.getParameter("inputCode");
			inputCode = inputCode.toUpperCase();
			HttpSession session = req.getSession();  
			verifyCode = (String)session.getAttribute("validateCode"); 
			UserNameLogin=(String)session.getAttribute("UserName");
//			System.out.println(verifyCode);
//			System.out.println(inputCode);

			if(UserName == null || "".equals(UserName.trim())||PassWord == null || "".equals(PassWord.trim())||inputCode == null || "".equals(inputCode.trim())) {
				f=0;//密码用户不能为空
			}else {
				Services ser=new ServicesImpl();
				List list=ser.login(UserName);
				us=list.get(0).toString();
				pw=list.get(1).toString();
				admin=list.get(2).toString();
				if(admin.equals("0")) {
					f=2;//不是管理员不能登陆
				}else{
					if(us.equals(UserName)&&pw.equals(PassWord)&&verifyCode.equals(inputCode)){
			            f=1;//登陆成功
			            
			            session.setAttribute("UserName", UserName);
			            
					}else {
						f=-1;//密码，用户名错误，验证码错误
					}
				}
			}
			PrintWriter out = res.getWriter();
			out.print(f);

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}
	
}

