package com.xbl.sevlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.xbl.services.Services;
import com.xbl.services.servicesImpl.ServicesImpl;

/**
 * Servlet implementation class Indexservlet
 */
@WebServlet("/Indexservlet")
public class Indexservlet extends HttpServlet {
	private Services ser=new ServicesImpl();
	
	@Override
	protected void service(HttpServletRequest req,HttpServletResponse res) throws  ServletException,IOException {
		try {
			res.setCharacterEncoding("UTF-8");
			req.setCharacterEncoding("UTF-8");
			List imageList= ser.index("image");
			List introductList=ser.index("introduct");
			List FoodNameList=ser.index("FoodName");
			List priceList=ser.index("price");
			PrintWriter out = res.getWriter();
			for(int i=0;i<imageList.size();i++) {
			String image="<image src='"+imageList.get(i)+"'/>";
			String introduct=introductList.get(i).toString();
			String FoodName=FoodNameList.get(i).toString();
			String price=priceList.get(i).toString();
			int x=i+1;
			out.print("<div id='xh'>"+x+"</div>");
			out.print("<div id='image'>"+image+"</div>");
			out.print("<div id='introduct'>"+introduct+"</div>");
			out.print("<div id='FoodName'>"+FoodName+"</div>");
			out.print("<div id='price'>"+price+"</div>");
			}
			
			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
