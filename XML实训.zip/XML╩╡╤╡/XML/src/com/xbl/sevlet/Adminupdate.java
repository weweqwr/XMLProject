package com.xbl.sevlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.xbl.services.Services;
import com.xbl.services.servicesImpl.ServicesImpl;


@WebServlet("/Adminupdate")
public class Adminupdate extends HttpServlet {
	
	
	private Services ser=new ServicesImpl();
	@Override
	public void service(ServletRequest req, ServletResponse res) throws ServletException, IOException {
		
		try{
		res.setCharacterEncoding("UTF-8");
		req.setCharacterEncoding("UTF-8");
		String id=req.getParameter("id");
		String FoodName=req.getParameter("FoodName");
		String image=req.getParameter("image");
		String introduct=req.getParameter("introduct");
		String price=req.getParameter("price");
		if(id == null || "".equals(id.trim())||FoodName == null || "".equals(FoodName.trim())||
				image == null || "".equals(image.trim())||introduct == null || "".equals(introduct.trim())
				||price==null||"".contentEquals(price.trim())
				) {
			PrintWriter out = res.getWriter();
			out.print("所有信息不能为空");
		}
		else {
			ser.adminupdate(id, FoodName, image, introduct, price);
			PrintWriter out = res.getWriter();
			out.print("修改成功");
		}
		}catch(Exception e) {
			e.printStackTrace();
			PrintWriter out = res.getWriter();
			out.print("修改失败");
		}
	}

}
