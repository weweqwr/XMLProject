package com.xbl.sevlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.xbl.services.Services;
import com.xbl.services.servicesImpl.ServicesImpl;

/**
 * Servlet implementation class Adminservlet
 */
@WebServlet("/AdminDeletesertservlet")
public class AdminDeletesertservlet extends HttpServlet {
	private Services ser=new ServicesImpl();
	@Override
	public void service(ServletRequest req, ServletResponse res) throws ServletException, IOException {
		// TODO Auto-generated method stub		
		try{
		res.setCharacterEncoding("UTF-8");
		req.setCharacterEncoding("UTF-8");
		String id=req.getParameter("id");
		if(id == null || "".equals(id.trim())) {
			PrintWriter out = res.getWriter();
			out.print("id不能为空");
		}else {
			ser.admindelete(id);
			PrintWriter out = res.getWriter();
			out.print("删除成功");
		}
		}catch(Exception e) {
			PrintWriter out = res.getWriter();
			out.print("删除失败");
			e.printStackTrace();
		}
	}
	
}
