package com.xbl.test;

import java.util.ArrayList;
import java.util.List;

import org.dom4j.Document;

import com.xbl.dao.Impl.GetDocument;
import com.xbl.dao.Impl.YueCaiDaoImpl;
import com.xbl.pojo.Entity;
import com.xbl.services.Services;
import com.xbl.services.servicesImpl.ServicesImpl;

public class Test {

	public static void main(String[] args) throws Exception {
		GetDocument get=new GetDocument();
		Services ser=new ServicesImpl();
		List list=ser.login("1");
		System.out.print(list.get(2));
	}
}
